# Screen Translator Android

Proyek awal penerjemah layar untuk Android 16 / ARM64.

## Fitur
- MediaProjection untuk menangkap layar setelah izin pengguna.
- Overlay di atas aplikasi lain.
- Dependensi ML Kit OCR dan on-device translation.
- Target SDK 36.
- Packaging native disiapkan untuk kompatibilitas modern.

## Build tanpa PC
Repository ini menyertakan GitHub Actions (`.github/workflows/build.yml`).
Upload proyek ke repository GitHub, lalu jalankan Actions -> Build APK.
Hasil `app-debug.apk` tersedia sebagai artifact.

## Catatan
Versi ini adalah fondasi yang dapat dibangun. Pipeline OCR -> terjemahan -> pembaruan overlay masih perlu dihubungkan pada worker pengambilan frame. Tidak ada APK jadi yang diklaim sudah diuji di perangkat pengguna.
